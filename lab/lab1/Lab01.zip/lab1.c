#include <stdio.h>

void printBinaryForm( int X )
//Purpose: Print parameter X in binary form
//Output: Binary representation of X directly printed
//Assumption: X is non-negative (i.e. >= 0)
{

	//[TODO] CHANGE this to your solution.
	printf("Binary form coming soon!\n");

}

void printHexadecimalForm( int X )
//Purpose: Print parameter X in hexadecimal form
//Output: Hexadecimal representation of X directly printed
//Assumption: X is non-negative (i.e. >= 0)
{

	//[TODO] CHANGE this to your solution.
	printf("Hexadecimal form coming soon!\n");

}
int main(void)
{
	int X; 	

	printf("Enter X: ");
	scanf("%d",&X);

	//print X in binary form
	printBinaryForm( X );

	//print X in hexadecimal form
	printHexadecimalForm( X );

	return 0;
}
