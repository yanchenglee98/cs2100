#include <stdio.h>

void display(int age) 
{
	printf("%d\n", age);
}

int main() 
{
	int ageArray[] = { 2, 15, 4 };
	
	display(ageArray[1]);

	return 0;
}